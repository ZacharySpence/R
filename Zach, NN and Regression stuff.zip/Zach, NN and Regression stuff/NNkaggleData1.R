## Installation

# install latest miniconda
# install latest RTools.exe
# install latest R version

install.packages("devtools")
library(devtools)
install.packages("keras")
library(keras)

# pip install tensorflow
# pip install keras
setwd("C:\\Users\\Admin\\Documents\\R Lessons")
## Data Wrangling
trainData <- read.csv("training_data_cleaned.csv")
testData <- read.csv("test_data_clean.csv")

# Load the data from the website
#data <- dataset_mnist()
trainData <- trainData[,c(10,6,22,27,28,56)]
trainData<- trainData[1:1459,]
testData <- testData[,c(10,6,22,27,28)]
#testData$SalePrice <- 0


#trainData <- trainData[,c(2,3,4,5,6,7,8,9,10,11,15,16,17,18,19,20,21,22,23,25,26,27,28,29,30,31,32,33,34,35,36,38,41,42,43,44,45,46,47,48,49,50,51,52,56)]
#testData <- testData[,c(2,3,4,5,6,7,8,9,10,11,15,16,17,18,19,20,21,22,23,25,26,27,28,29,30,31,32,33,34,35,36,38,41,42,43,44,45,46,47,48,49,50,51,52,56)]
#testData$SalePrice <- 0
#trainData$Neighborhood <- as.numeric(trainData$Neighborhood)
#testData$Neighborhood <- as.numeric(testData$Neighborhood)
# Split the raw data into suitable groupings
# x = Input (pixel values), y = Output (number categories)
Train <- trainData[,-c(6)]
trainTarget <- trainData$SalePrice
Test <- testData
#testTarget <- testData$SalePrice

# Reshape into matrices
#x_train <- array_reshape(x_train, c(nrow(x_train), 1459))
#x_test <- array_reshape(x_test, c(nrow(x_test), 44))

TrainMatrix <- data.matrix(Train)
TestMatrix <- data.matrix(Test)


TestMatrix[is.na(TestMatrix)] <- 0
#trainData[is.na(trainData)] <- 0

FeatureScaling <- function(x) { ((x - min(x)) / (max(x) - min(x))) }
Denormalize <- function(x,y) {(x*(max(y)-min(y))+min(y))}
#This corresponds to the equation given in the slides

#Data_Normalised <- as.data.frame(lapply(Data_NoResults, FeatureScaling))
#x_Ntrain <- FeatureScaling(x_train)
#y_Ntrain <- FeatureScaling(y_train)
#x_Ntest <- FeatureScaling(x_test)
#x_Ntest <- array_reshape(x_test, c(nrow(x_test), 44))

NTrainTarget <- normalize(trainTarget)
NTrainMatrix <- normalize(TrainMatrix)
NTestMatrix <- normalize(TrainMatrix)
NTestMatrix <- array_reshape(NTestMatrix, c(nrow(Test), 5))

#x_test <- data.matrix(x_test)
# Scale to turn them into range 0-1
#x_train <- x_train / 255
#x_test <- x_test / 255

# Turns the integers into classes suitable for Keras' processing
#y_train <- to_categorical(y_train, 1459)
#y_test <- to_categorical(y_test, 1459)

## Build the Neural Network

# Base network creation - used as scaffolding to attach other layers
neural_network <- keras_model_sequential()

# Add layers with the pipe (%>%) operator
neural_network %>% 
  layer_dense(units = 1459, activation = 'relu', input_shape = c(5)) %>% 
  layer_dropout(rate = 0.4) %>% 
  layer_dense(units = 1203, activation = 'relu') %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 1007, activation = 'relu') %>%
  layer_dropout(rate = 0.3) %>%
  layer_dense(units = 811, activation = 'relu') %>%
  layer_dropout(rate = 0.2) %>%
  layer_dense(units = 615, activation = 'relu') %>%
  layer_dropout(rate = 0.2) %>%
  layer_dense(units = 419, activation = 'relu') %>%
  layer_dropout(rate = 0.1) %>%
  layer_dense(units = 223, activation = 'relu') %>%
  layer_dropout(rate = 0.1) %>%
  layer_dense(units = 1, activation = 'linear')

# Compile the model

neural_network %>% compile(
  loss = 'mean_squared_error',
  optimizer = optimizer_rmsprop(lr=0.03),
  metrics = c('accuracy')
)

# Train the model, recording performance in a variable

history <- neural_network %>% fit(
  NTrainMatrix, trainTarget, 
  epochs = 5, batch_size = 54, 
  validation_split = 0.2
)


#Denormalise the data
#x_test <- (Denormalize(x_Ntest,x_test))
#x_train <- Denormalize(x_Ntrain,x_train)
#y_train <- Denormalize(y_Ntrain,y_train)

# View the history
# Only needed if Keras interactive graph doesn't load

#plot(history)

# Evaluate performance

#neural_network %>% evaluate(TestMatrix, TrainMatrix)
#write.csv(x_testmatrix, "diditwork.csv")

# Generate predictions

#NO DATA BECAUSE I HAVE 0'S and it's predicting everything as 0's
predictions <- neural_network %>% predict(NTestMatrix)
write.csv(predictions, "diditwork.csv")
neural_network %>% evaluate(NTestMatrix, predictions)

