## Installation

# install latest miniconda
# install latest RTools.exe
# install latest R version

install.packages("devtools")
library(devtools)
install.packages("keras")
library(keras)

# pip install tensorflow
# pip install keras

## Data Wrangling

# Load the data from the website
data <- dataset_cifar10()

# Split the raw data into suitable groupings
# x = Input (pixel values), y = Output (number categories)
x_train <- data$train$x/255
y_train <- to_categorical(data$train$y, num_classes = 10)
x_test <- data$test$x/255
y_test <- to_categorical(data$test$y, num_classes =10)

# Reshape into matrices
#x_train <- array_reshape(x_train, c(nrow(x_train), 3072))
#x_test <- array_reshape(x_test, c(nrow(x_test), 3072))

# Scale to turn them into range 0-1
#x_train <- x_train / 255
#x_test <- x_test / 255

# Turns the integers into classes suitable for Keras' processing
#y_train <- to_categorical(y_train, 10)
#y_test <- to_categorical(y_test, 10)

## Build the Neural Network

# Base network creation - used as scaffolding to attach other layers
neural_network <- keras_model_sequential()

# Add layers with the pipe (%>%) operator
neural_network %>% 
  layer_conv_2d(filter=32,kernel_size=c(3,3),padding="same",input_shape=c(32,32,3), activation = "relu") %>%
  layer_conv_2d(filter=32, kernel_size=c(3,3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_dropout(0.25) %>%
  layer_flatten() %>%
  layer_dense(units = 512, activation = 'relu') %>%
  layer_dropout(rate = 0.5) %>%
  layer_dense(units = 10, activation = 'softmax')

# Compile the model
opt <- optimizer_adam(lr == 0.0001, decay = 1e-6)
neural_network %>% compile(
  loss = 'categorical_crossentropy',
  optimizer = optimizer_rmsprop(),
  metrics = c('accuracy')
)

# Train the model, recording performance in a variable

history <- neural_network %>% fit(
  x_train, y_train, 
  epochs = 30, batch_size = 128, 
  validation_split = 0.2
)

# View the history
# Only needed if Keras interactive graph doesn't load

plot(history)

# Evaluate performance

neural_network %>% evaluate(x_test, y_test)

# Generate predictions

neural_network %>% predict_classes(x_test)


# GENERATE IMAGES
data_augmentation <- TRUE

if (!data_augmentation){
  model %>% fit(train_x,train_y,batch_size = 128,epochs=10, validation_data = list(test_x,test_y),shuffle=TRUE)
}else{
  gen_images <- image_data_generator(featurewise_center = TRUE,
                                     featurewise_std_normalization = TRUE,
                                     rotation_range = 20,
                                     width_shift_range = 0.30,
                                     height_shift_range = 0.30,
                                     horizontal_flip = TRUE)
                                     
  gen_images %>% fit_generator(
    flow_images_from_data(train_x,train_y,gen_images,
                           batch_size=32, save_to_dir="C:/Users/Admin/Documents/R Lessons"),
    steps_per_epoch = as.integer(50000/32),epochs = 10,
    validation_data = list(test_x,test_y))
}
