setwd("C:\\Users\\Admin\\Documents\\R Lessons")
trainData <- read.csv("training_data_cleaned.csv")
testData <- read.csv("test_data_clean.csv")
#trainData <- trainData[,c(10,6,22,27,28,56)]
trainData<- trainData[1:1459,]
#testData <- testData[,c(10,6,22,27,28)]
testData$SalePrice <- 0

trainData <- trainData[,c(2,3,4,5,6,7,8,9,10,11,15,16,17,18,19,20,21,22,23,25,26,27,28,29,30,31,32,33,34,35,36,38,41,42,43,44,45,46,47,48,49,50,51,52,56)]
testData <- testData[,c(2,3,4,5,6,7,8,9,10,11,15,16,17,18,19,20,21,22,23,25,26,27,28,29,30,31,32,33,34,35,36,38,41,42,43,44,45,46,47,48,49,50,51,52,56)]
#trainData <- as.data.frame(sapply(trainData, as.numeric))
#testData <- as.data.frame(sapply(testData, as.numeric))
#AS NUMERICS -> 17,18,38 43,44
testData$BsmtQual <- as.numeric(testData$BsmtQual)
trainData$BsmtQual <- as.numeric(trainData$BsmtQual)
testData$ExterQual <- as.numeric(testData$ExterQual)
trainData$ExterQual <- as.numeric(trainData$ExterQual)
testData$ExterCond <- as.numeric(testData$ExterCond)
trainData$ExterCond <- as.numeric(trainData$ExterCond)
testData$BsmtCond <- as.numeric(testData$BsmtCond)
trainData$BsmtCond <- as.numeric(trainData$BsmtCond)
testData$KitchenQual <- as.numeric(testData$KitchenQual)
trainData$KitchenQual <- as.numeric(trainData$KitchenQual)
testData$GarageQual <- as.numeric(testData$GarageQual)
trainData$GarageQual <- as.numeric(trainData$GarageQual)
testData$GarageCond <- as.numeric(testData$GarageCond)
trainData$GarageCond <- as.numeric(trainData$GarageCond)
#write.csv(testData, "dataaaa")
testData[is.na(testData)] <- 0
trainData[is.na(trainData)] <- 0

#FeatureScaling <- function(x) { ((x - min(x)) / (max(x) - min(x))) }

#trainData <- as.data.frame(lapply(trainData, FeatureScaling))
#testData <- as.data.frame(lapply(trainData, FeatureScaling))

linearModel <- lm(SalePrice ~., data = trainData)





pred <- predict(linearModel,testData)
print(pred)
tablepred <- table(linearModel, testData)
print(tablepred)
#Build an MSE!!

write.csv(pred, "TestingStuff.csv")
plot(tablepred)
summary(tablepred)

