library (rpart)

setwd("C:\\Users\\Admin\\Documents\\R Lessons")
data <- read.csv("training_data_cleaned.csv")
testData <- read.csv("test_data_clean.csv", headers = TRUE)
#Cleaning data
data <- data[1:1459,]
testData <- testData[,c(10,6,22,27,28)]
testData[is.na(testData)] <- 0
write.csv(testData,"going.csv")
#data$Bathroom <- rowSums(data[,48:51])
testData$SalePrice <- 0
#testData$Bathroom <- rowSums(data[,48:51])
#Bilal
#fit <- rpart(SalePrice~CentralAir+Electrical+X1stFlrSF+X2ndFlrSF+GrLivArea+TotRmsAbvGrd+KitchenAbvGr+BedroomAbvGr+Bathroom, data = data, control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~X1stFlrSF+X2ndFlrSF+GrLivArea+Bathroom, data = data, control = rpart.control(minsplit=5))

#Bilal + Leo
#fit <- rpart(SalePrice~YearRemodAdd+ExterQual+BsmtQual+BsmtFinSF1+TotalBsmtSF+X1stFlrSF+X2ndFlrSF+GrLivArea+Bathroom, data = data, control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~ExterQual+BsmtQual+TotalBsmtSF+X2ndFlrSF+GrLivArea, data = data, control = rpart.control(minsplit=5))

#Leo
#fit <- rpart(SalePrice~YearRemodAdd+Exterior1st+MasVnrType+ExterQual+ExterCond+Foundation+BsmtQual+BsmtCond+BsmtExposure+BsmtFinSF1+TotalBsmtSF, data = data, method = "anova", control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~YearRemodAdd+ExterQual+BsmtQual+BsmtFinSF1+TotalBsmtSF, data = data, method = "anova", control = rpart.control(minsplit=5))


#Jake
#fit <- rpart(SalePrice~GarageType+GarageFinish+GarageQual+GarageCond+PavedDrive+WoodDeckSF+OpenPorchSF+EnclosedPorch+X3SsnPorch+PoolQC+Fence+MiscFeature+MoSold+SaleType, data=data, method = "anova",control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~GarageFinish+PavedDrive+WoodDeckSF+OpenPorchSF+EnclosedPorch+Fence+SaleType, data=data, method = "anova",control = rpart.control(minsplit=5))

#Jake,Bilal & Leo
#fit <- rpart(SalePrice~GarageFinish+PavedDrive+WoodDeckSF+OpenPorchSF+EnclosedPorch+Fence+SaleType+YearRemodAdd+ExterQual+BsmtQual+BsmtFinSF1+TotalBsmtSF+X1stFlrSF+X2ndFlrSF+GrLivArea+Bathroom, data=data, method = "anova",control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~ExterQual+BsmtQual+TotalBsmtSF+X2ndFlrSF+GrLivArea, data=data, method = "anova",control = rpart.control(minsplit=5))

#Zach
#fit <- rpart(SalePrice~ YearBuilt+OverallCond+OverallQual+HouseStyle+BldgType+Condition2+Condition1+Neighborhood+LandSlope+LotConfig+Utilities+LandContour+LotShape+Alley+Street+LotArea+LotFrontage+MSZoning+MSSubClass, data=data, method="anova", control = rpart.control(minsplit=5))
#fit <- rpart(SalePrice~ YearBuilt+OverallQual+Neighborhood+LotArea, data=data, method="anova", control = rpart.control(minsplit=5))

#All
#fit <- rpart(SalePrice~YearBuilt+OverallQual+Neighborhood+LotArea+GarageFinish+PavedDrive+WoodDeckSF+OpenPorchSF+EnclosedPorch+Fence+SaleType+YearRemodAdd+ExterQual+BsmtQual+BsmtFinSF1+TotalBsmtSF+X1stFlrSF+X2ndFlrSF+GrLivArea+Bathroom, data=data, method = "anova",control = rpart.control(minsplit=5))
fit <- rpart(SalePrice~OverallQual+Neighborhood+TotalBsmtSF+X2ndFlrSF+GrLivArea, data = data, method = "anova", control = rpart.control(minsplit=5))


predictions <- predict(fit, testData)
tablepred <- table(testData$SalePrice, predictions)
print(tablepred)

mes <- mean((data$SalePrice - predictions)^2)

#Most fitted
forest <- randomForest(SalePrice~OverallQual+Neighborhood+TotalBsmtSF+X2ndFlrSF+GrLivArea, data = data)
#Less Fitted
#forest <- randomForest(SalePrice~OverallQual+Neighborhood+GarageFinish+WoodDeckSF+OpenPorchSF+EnclosedPorch+SaleType+YearRemodAdd+ExterQual+BsmtQual+BsmtFinSF1+TotalBsmtSF+X1stFlrSF+X2ndFlrSF+GrLivArea+Bathroom, data = data)
pred <- predict(forest,testData, type ="class")
print(pred)
tablepred <- table(testData$SalePrice, predictions)
print(tablepred)
write.csv(pred,"Predpred.csv")
print(forest)





